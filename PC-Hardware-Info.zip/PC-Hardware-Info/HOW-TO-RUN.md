# Comment exécuter PC-Hardware-Info

Ce fichier explique, étape par étape, comment **compiler** puis **lancer**
le programme sur **Windows**, **Linux** et **macOS (Apple)**.

Le programme a été conçu pour **Windows** : c'est sur Windows qu'il affiche
toutes les informations (CPU, RAM, disques, GPU, version de Windows).
Sur Linux et macOS il compile et tourne aussi, mais quelques sections
s'affichent `Unavailable` (voir les notes en bas de chaque partie).

---

## 🪟 Sur Windows

### Méthode 1 : Visual Studio (si tu l'as déjà) — la plus rapide

1. Menu démarrer → tape **`x64 Native Tools Command Prompt`** → ouvre
   celle de **Visual Studio** (ex. « *x64 Native Tools Command Prompt
   for Visual Studio 2022* »).
   ⚠️ Ce n'est pas l'invite de commandes classique : c'est cette fenêtre
   spéciale qui connaît le compilateur `cl`.
2. Va dans le dossier du projet et compile, **une commande à la fois** :

   ```bat
   cd /d C:\chemin\vers\PC-Hardware-Info
   cl /EHsc src\*.cpp advapi32.lib /FePC-Hardware-Info.exe
   ```

   (Il ne faut **pas** écrire `/std:c++11` : les versions récentes de
   Visual Studio ne supportent plus C++11 — le standard par défaut,
   C++14, suffit.)
3. Lance le programme :

   ```bat
   PC-Hardware-Info.exe
   ```

Notes :

- `advapi32.lib` = bibliothèque du registre Windows (indispensable).
- `src\*.cpp` = tous les fichiers .cpp du dossier `src`.
- Les **warnings** (D9002, C4530, etc.) peuvent apparaître : ignore-les,
  tant qu'il n'y a pas d'**error**, l'exe est bon.
- Les fichiers `.obj` dans le dossier sont normaux (fichiers de travail).
- Laisse la fenêtre de commande **ouverte** pendant l'utilisation :
  si tu double-cliques sur l'exe, la fenêtre se ferme en quittant.

### Méthode 2 : MinGW (WinLibs)

1. Télécharge le dernier `gcc-*-winlibs-*-minimal.zip` sur
   [winlibs.com](https://winlibs.com) et décompresse-le (ex. `C:\mingw`).
2. Ajoute `C:\mingw\bin` à la variable d'environnement `PATH`
   (menu démarrer → « *Variables d'environnement système* » → `Path` →
   Modifier → Nouveau), puis **ferme et rouvre** ton terminal.
3. Dans un terminal, dans le dossier du projet :

   ```bat
   cd C:\chemin\vers\PC-Hardware-Info
   g++ -std=c++11 -o PC-Hardware-Info.exe src\main.cpp src\CPU.cpp src\RAM.cpp src\Storage.cpp src\GPU.cpp src\System.cpp src\Report.cpp
   PC-Hardware-Info.exe
   ```

### Méthode 3 : CMake (avec Visual Studio ou MinGW installé)

```bat
cd C:\chemin\vers\PC-Hardware-Info
cmake -B build
cmake --build build
build\PC-Hardware-Info.exe
```

---

## 🐧 Sur Linux

1. Installe le compilateur si besoin (Debian/Ubuntu) :

   ```bash
   sudo apt install build-essential
   ```

   (Fedora : `sudo dnf install gcc-c++` — Arch : `sudo pacman -S base-devel`)
2. Dans le dossier du projet :

   ```bash
   cd PC-Hardware-Info
   g++ -std=c++11 -o PC-Hardware-Info src/main.cpp src/CPU.cpp src/RAM.cpp src/Storage.cpp src/GPU.cpp src/System.cpp src/Report.cpp
   ./PC-Hardware-Info
   ```

3. Note : le programme est fait pour Windows. Sous Linux, une version de
   secours lit les fichiers `/proc` pour le CPU, la RAM et le disque, mais
   les sections **GPU** et **Windows** s'affichent `Unavailable`.

---

## 🍎 Sur macOS (Apple)

1. La première fois, installe les outils de développement Apple :

   ```bash
   xcode-select --install
   ```

   (une fenêtre pop-up propose le téléchargement : « Continue »)
2. Dans le dossier du projet :

   ```bash
   cd PC-Hardware-Info
   g++ -std=c++11 -o PC-Hardware-Info src/main.cpp src/CPU.cpp src/RAM.cpp src/Storage.cpp src/GPU.cpp src/System.cpp src/Report.cpp
   ./PC-Hardware-Info
   ```

3. Note : macOS n'a pas les API Windows ni le dossier `/proc` : les
   sections **CPU** (nom/cœurs), **RAM**, **GPU** et **Windows**
   s'affichent `Unavailable`. Le **stockage** et l'**architecture**
   (x64 ou arm64) fonctionnent. Pour de vraies infos sur Mac, il
   faudrait adapter le code avec les fonctions Apple (`sysctl`) —
   une bonne idée de projet pour la suite !

---

## Après la compilation (tous les systèmes)

- **1 à 5** : une information à la fois (CPU, RAM, Windows, disques, GPU)
- **6** : tout sur un écran
- **7** : écrit tout dans le fichier `reports/system_report.txt`
  (le dossier `reports` est créé tout seul, à côté du dossier où tu
  as lancé le programme)
- **8** : quitte
- Après chaque écran : appuie sur **Entrée** pour revenir au menu.
