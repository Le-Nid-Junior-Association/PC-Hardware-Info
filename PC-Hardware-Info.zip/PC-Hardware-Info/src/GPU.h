// GPU.h
// -------------------------------------------------------------------
// Declaration de la fonction qui lit le(s) nom(s) de la carte
// graphique (getGpuInfo) et de la fonction qui les affiche
// (printGpuInfo).
// -------------------------------------------------------------------

#ifndef GPU_H
#define GPU_H

#include <string>
#include <vector>

// Lit le(s) nom(s) de la carte graphique.
// Si aucun nom ne peut etre lu, le vector reste vide.
std::vector<std::string> getGpuInfo();

// Affiche les informations de la carte graphique a l'ecran.
void printGpuInfo(const std::vector<std::string>& names);

#endif // GPU_H
