// GPU.cpp
// -------------------------------------------------------------------
// Comment le programme lit les informations de la carte graphique :
//   - Windows : registre, classe "Display" (cartes graphiques).
//     Le chemin dans le registre est :
//       HKLM\SYSTEM\CurrentControlSet\Control\Class
//       avec la classe "Display" {4d36e968-e325-11ce-bfc1-08002be10318}
//     Chaque sous-cle (0000, 0001, ...) est une carte graphique,
//     et sa valeur "DriverDesc" est son nom.
//   - Linux / macOS : pas d'equivalent simple : "Unavailable".
// -------------------------------------------------------------------

#include "GPU.h"
#include "System.h" // pour readRegistryString()

#include <iostream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

#ifdef _WIN32

// "0" -> "0000", "3" -> "0003", "12" -> "0012"
static std::string fourDigits(int i) {
    std::string s = std::to_string(i);
    while (s.size() < 4) {
        s = "0" + s;
    }
    return s;
}

std::vector<std::string> getGpuInfo() {
    std::vector<std::string> names;

    // La classe "Display" du registre (les cartes graphiques).
    const std::string classPath =
        "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}";

    // Chaque sous-cle 0000, 0001, ... est une carte graphique
    // (la plupart des PC en ont 1 ou 2).
    for (int i = 0; i < 16; i = i + 1) {
        std::string name = readRegistryString(
            (classPath + "\\" + fourDigits(i)).c_str(),
            "DriverDesc");

        if (name != "Unavailable") {
            names.push_back(name);
        }
    }

    return names;
}

#else // -------------------------------------------------------------
// Hors Windows : pas de lecture simple de la carte graphique.
// -------------------------------------------------------------

std::vector<std::string> getGpuInfo() {
    return std::vector<std::string>();
}

#endif // _WIN32

// -------------------------------------------------------------------
// Affichage (identique sur tous les systemes)
// -------------------------------------------------------------------

void printGpuInfo(const std::vector<std::string>& names) {
    std::cout << "GPU" << std::endl;

    if (names.empty()) {
        std::cout << "Unavailable" << std::endl;
        std::cout << std::endl;
        return;
    }

    for (std::size_t i = 0; i < names.size(); i = i + 1) {
        std::cout << "Name: " << names[i] << std::endl;
    }

    std::cout << std::endl;
}
