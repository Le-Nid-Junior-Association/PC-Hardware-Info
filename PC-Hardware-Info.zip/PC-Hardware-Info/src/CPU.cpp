// CPU.cpp
// -------------------------------------------------------------------
// Comment le programme lit les informations du processeur :
//   - nom         : registre Windows (ProcessorNameString)
//   - coeurs      : fonction Windows GetLogicalProcessorInformation()
//   - threads     : fonction Windows GetLogicalProcessorInformation()
//   - architecture: fonction getSystemArchitecture() (System.cpp)
//
// Sur les systemes non-Windows (Linux), une version de secours simple
// lit le fichier /proc/cpuinfo pour pouvoir tester le programme.
// -------------------------------------------------------------------

#include "CPU.h"
#include "System.h" // pour getSystemArchitecture() et readRegistryString()

#include <iostream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#else
#include <fstream>
#endif

// -------------------------------------------------------------------
// Petites fonctions d'aide (en "static" : privees a ce fichier)
// -------------------------------------------------------------------

// Si le texte est vide, retourne "Unavailable", sinon le texte.
static std::string textOrUnavailable(const std::string& value) {
    if (value.empty()) {
        return "Unavailable";
    }
    return value;
}

// Convertit un nombre en texte. 0 (non disponible) devient
// "Unavailable".
static std::string numberOrUnavailable(int value) {
    if (value <= 0) {
        return "Unavailable";
    }
    return std::to_string(value);
}

#ifdef _WIN32

// Compte combien de processeurs sont representes par les bits
// values a 1 dans un masque de 32 bits.
static int countProcessorsInMask(unsigned int mask) {
    int count = 0;
    for (int i = 0; i < 32; i = i + 1) {
        if (mask & (1u << i)) {
            count = count + 1;
        }
    }
    return count;
}

// Lit le nombre de coeurs physiques et de threads logiques.
static void getCoresAndThreads(int& cores, int& threads) {
    cores = 0;
    threads = 0;

    // Premier appel : on demande a Windows combien de memoire
    // est necessaire.
    DWORD bufferSize = 0;
    GetLogicalProcessorInformation(nullptr, &bufferSize);
    if (bufferSize == 0) {
        return; // information non disponible sur ce systeme
    }

    // Deuxieme appel : on recoit les vraies donnees dans un
    // std::vector (les groupes de processeurs).
    const DWORD structSize = sizeof(SYSTEM_LOGICAL_PROCESSOR_INFORMATION);
    std::vector<SYSTEM_LOGICAL_PROCESSOR_INFORMATION> groups(bufferSize / structSize);

    if (!GetLogicalProcessorInformation(groups.data(), &bufferSize)) {
        return; // l'appel a echoue
    }

    // Chaque groupe de type "RelationProcessorCore" est un coeur
    // physique. Son masque indique combien de threads il possede.
    const DWORD groupCount = bufferSize / structSize;
    for (DWORD i = 0; i < groupCount; i = i + 1) {
        if (groups[i].Relationship == RelationProcessorCore) {
            cores = cores + 1;
            threads = threads + countProcessorsInMask(groups[i].ProcessorMask);
        }
    }
}

void getCpuInfo(CpuInfo& cpu) {
    // Valeurs par defaut, au cas ou un appel echoue.
    cpu.name = "Unavailable";
    cpu.cores = 0;
    cpu.threads = 0;
    cpu.architecture = getSystemArchitecture();

    // 1) Nom du processeur, dans le registre Windows.
    cpu.name = readRegistryString(
        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
        "ProcessorNameString");

    // 2) Nombre de coeurs et de threads.
    getCoresAndThreads(cpu.cores, cpu.threads);

    // 3) Si le nombre de threads n'a pas pu etre obtenu (rare),
    //    SYSTEM_INFO donne le nombre de processeurs logiques.
    if (cpu.threads <= 0) {
        SYSTEM_INFO info;
        GetSystemInfo(&info);
        cpu.threads = static_cast<int>(info.dwNumberOfProcessors);
    }
}

#else // -------------------------------------------------------------
// Version de secours pour Linux (test du programme hors Windows).
// -------------------------------------------------------------

// Extrait la valeur d'une ligne de /proc/cpuinfo.
// Exemple : "model name\t: Intel(R) Xeon(R) CPU" -> "Intel(R) Xeon(R) CPU"
static std::string extractProcValue(const std::string& line) {
    const std::size_t pos = line.find(':');
    if (pos == std::string::npos || pos + 2 >= line.size()) {
        return "";
    }
    return line.substr(pos + 2);
}

void getCpuInfo(CpuInfo& cpu) {
    cpu.name = "Unavailable";
    cpu.cores = 0;
    cpu.threads = 0;
    cpu.architecture = getSystemArchitecture();

    // Sur Linux, les informations du processeur sont dans /proc/cpuinfo.
    std::ifstream file("/proc/cpuinfo");
    if (!file.is_open()) {
        return; // fichier introuvable : tout reste "Unavailable"
    }

    std::string line;
    std::string currentPhysicalId = "0";
    std::vector<std::string> coreKeys;

    while (std::getline(file, line)) {
        if (line.rfind("physical id", 0) == 0) {
            currentPhysicalId = extractProcValue(line);
        } else if (line.rfind("core id", 0) == 0) {
            // Cle "physical id + core id" : unique pour chaque coeur.
            coreKeys.push_back(currentPhysicalId + "-" + extractProcValue(line));
        } else if (line.rfind("model name", 0) == 0) {
            cpu.name = extractProcValue(line);
        } else if (line.rfind("processor", 0) == 0) {
            cpu.threads = cpu.threads + 1;
        }
    }

    // Nombre de coeurs : nombre de cles differentes.
    for (std::size_t i = 0; i < coreKeys.size(); i = i + 1) {
        bool alreadyCounted = false;
        for (std::size_t j = 0; j < i; j = j + 1) {
            if (coreKeys[i] == coreKeys[j]) {
                alreadyCounted = true;
                break;
            }
        }
        if (!alreadyCounted) {
            cpu.cores = cpu.cores + 1;
        }
    }
}

#endif // _WIN32

// -------------------------------------------------------------------
// Affichage (identique sur tous les systemes)
// -------------------------------------------------------------------

void printCpuInfo(const CpuInfo& cpu) {
    std::cout << "CPU" << std::endl;
    std::cout << "Name: " << textOrUnavailable(cpu.name) << std::endl;
    std::cout << "Cores: " << numberOrUnavailable(cpu.cores) << std::endl;
    std::cout << "Threads: " << numberOrUnavailable(cpu.threads) << std::endl;
    std::cout << "Architecture: " << textOrUnavailable(cpu.architecture) << std::endl;
    std::cout << std::endl;
}
