// Storage.cpp
// -------------------------------------------------------------------
// Comment le programme lit les informations des disques :
//   - Windows : GetLogicalDrives() + GetDiskFreeSpaceExA()
//   - Linux   : fonction statvfs() sur "/" (version de secours,
//               voir README)
//
// L'espace utilise est calcule ainsi :
//   utilise = total - libre
// -------------------------------------------------------------------

#include "Storage.h"

#include <iostream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/statvfs.h>
#endif

#ifdef _WIN32

std::vector<DriveInfo> getStorageInfo() {
    std::vector<DriveInfo> drives;

    // GetLogicalDrives() renvoie un "masque" : si le bit i est a 1,
    // alors la lettre de disque 'A' + i existe.
    const DWORD driveMask = GetLogicalDrives();

    for (int i = 0; i < 26; i = i + 1) {
        if (!(driveMask & (1u << i))) {
            continue; // cette lettre de disque n'existe pas
        }

        // On construit le nom du disque : "C:\"
        char driveName[4];
        driveName[0] = static_cast<char>('A' + i);
        driveName[1] = ':';
        driveName[2] = '\\';
        driveName[3] = '\0';

        ULARGE_INTEGER totalBytes;
        ULARGE_INTEGER totalFreeBytes;
        ULARGE_INTEGER freeBytesForUser;

        if (!GetDiskFreeSpaceExA(driveName, &totalBytes, &totalFreeBytes,
                                 &freeBytesForUser)) {
            continue; // impossible de lire ce disque
                     // (par exemple une cle USB deconnectee)
        }

        if (totalBytes.QuadPart == 0) {
            continue; // aucune taille renvoyee
                     // (souvent une unite reseau)
        }

        // Les disques sont vendus en gigaoctets "decimaux", comme
        // Windows (1 GB = 1 000 000 000 octets) : un disque "500 GB"
        // s'affiche comme 500 GB ici, comme dans l'Explorateur.
        // (La memoire, elle, est vendue en binaire : voir RAM.cpp.)
        const unsigned long long oneGb = 1000ULL * 1000ULL * 1000ULL;

        DriveInfo drive;
        drive.letter = std::string(1, driveName[0]) + ":";
        drive.totalGb = totalBytes.QuadPart / oneGb;
        drive.freeGb = freeBytesForUser.QuadPart / oneGb;
        drive.usedGb = drive.totalGb - drive.freeGb;

        drives.push_back(drive);
    }

    return drives;
}

#else // -------------------------------------------------------------
// Version de secours pour Linux (test du programme hors Windows).
// -------------------------------------------------------------

std::vector<DriveInfo> getStorageInfo() {
    std::vector<DriveInfo> drives;

    // Version simple : on lit le disque monte sur "/".
    // Comme pour Windows, on affiche en GB decimaux
    // (1 GB = 1 000 000 000 octets).
    struct statvfs info;
    if (statvfs("/", &info) == 0) {
        const unsigned long long oneGb = 1000ULL * 1000ULL * 1000ULL;
        const unsigned long long totalBytes =
            static_cast<unsigned long long>(info.f_blocks) * info.f_frsize;
        const unsigned long long freeBytes =
            static_cast<unsigned long long>(info.f_bavail) * info.f_frsize;

        DriveInfo drive;
        drive.letter = "/";
        drive.totalGb = totalBytes / oneGb;
        drive.freeGb = freeBytes / oneGb;
        drive.usedGb = drive.totalGb - drive.freeGb;

        drives.push_back(drive);
    }

    return drives;
}

#endif // _WIN32

// -------------------------------------------------------------------
// Affichage (identique sur tous les systemes)
// -------------------------------------------------------------------

void printStorageInfo(const std::vector<DriveInfo>& drives) {
    std::cout << "STORAGE" << std::endl;

    if (drives.empty()) {
        std::cout << "Unavailable" << std::endl;
        std::cout << std::endl;
        return;
    }

    for (std::size_t i = 0; i < drives.size(); i = i + 1) {
        std::cout << drives[i].letter << std::endl;
        std::cout << "Total: " << drives[i].totalGb << " GB" << std::endl;
        std::cout << "Used: " << drives[i].usedGb << " GB" << std::endl;
        std::cout << "Free: " << drives[i].freeGb << " GB" << std::endl;
        std::cout << std::endl;
    }
}
