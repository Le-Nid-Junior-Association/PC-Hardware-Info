// System.h
// -------------------------------------------------------------------
// Declaration de la structure SystemInfo et des fonctions qui
// lisent les informations du systeme (getSystemInfo), qui les
// affichent (printSystemInfo) et qui affichent le rapport complet
// (printSystemReport).
// -------------------------------------------------------------------

#ifndef SYSTEM_H
#define SYSTEM_H

#include <string>

#include "CPU.h"     // structure CpuInfo (pour le rapport complet)
#include "RAM.h"     // structure RamInfo (pour le rapport complet)
#include "Storage.h" // structure DriveInfo (pour le rapport complet)

// Petite structure qui stocke les informations du systeme.
struct SystemInfo {
    std::string architecture;   // "x64" ou "x86"
    std::string windowsVersion; // Exemple : "Windows 11 Pro"
};

// Retourne l'architecture du systeme : "x64", "x86" ou "Unavailable".
std::string getSystemArchitecture();

// Sur Windows : lit une valeur texte dans le registre.
// Retourne "Unavailable" si la valeur ne peut pas etre lue.
std::string readRegistryString(const char* path, const char* valueName);

// Lit les informations du systeme et remplit la structure.
void getSystemInfo(SystemInfo& info);

// Affiche les informations du systeme a l'ecran.
void printSystemInfo(const SystemInfo& info);

// Affiche le rapport complet (CPU + RAM + STORAGE + GPU + systeme).
void printSystemReport(const CpuInfo& cpu, const RamInfo& ram,
                       const SystemInfo& system,
                       const std::vector<DriveInfo>& drives,
                       const std::vector<std::string>& gpus);

#endif // SYSTEM_H
