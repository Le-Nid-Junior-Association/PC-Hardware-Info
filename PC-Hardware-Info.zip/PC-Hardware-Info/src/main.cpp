// main.cpp
// -------------------------------------------------------------------
// PC-Hardware-Info
//
// Petite application console en C++ qui affiche les informations
// principales du PC : CPU, RAM, Windows, disques (STORAGE) et
// carte graphique (GPU).
//
// Organisation du projet :
//   - CPU.cpp / CPU.h         : les informations du processeur
//   - RAM.cpp / RAM.h         : les informations de la memoire
//   - Storage.cpp / Storage.h : les informations des disques
//   - GPU.cpp / GPU.h         : les informations de la carte graphique
//   - System.cpp / System.h   : les informations du systeme + le rapport ecran
//   - Report.cpp / Report.h   : l'export du rapport dans un fichier .txt
// -------------------------------------------------------------------

#include <iostream>
#include <string>
#include <vector>

#include "CPU.h"
#include "GPU.h"
#include "RAM.h"
#include "Report.h"
#include "Storage.h"
#include "System.h"

// Affiche le menu principal a l'ecran.
static void printMenu() {
    std::cout << "================================" << std::endl;
    std::cout << "       PC HARDWARE INFO" << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << std::endl;

    // Les options du menu sont stockees dans un std::vector.
    std::vector<std::string> options;
    options.push_back("Show CPU information");
    options.push_back("Show RAM information");
    options.push_back("Show Windows information");
    options.push_back("Show storage information");
    options.push_back("Show GPU information");
    options.push_back("Show all information");
    options.push_back("Export system report");
    options.push_back("Exit");

    // Une simple boucle pour afficher les options une par une.
    for (std::size_t i = 0; i < options.size(); i = i + 1) {
        std::cout << (i + 1) << ". " << options[i] << std::endl;
    }

    std::cout << std::endl;
    std::cout << "Choose an option: ";
}

// Affiche le message a montrer quand l'utilisateur entre une
// option invalide.
static void printInvalidOption() {
    std::cout << "Invalid option." << std::endl;
    std::cout << "Please try again." << std::endl;
    std::cout << std::endl;
}

// Affiche un petit message et attend que l'utilisateur appuie
// sur la touche "Entree".
static void pressEnter() {
    std::cout << "Press Enter to return to the menu...";
    std::string line;
    std::getline(std::cin, line);
    std::cout << std::endl;
}

int main() {
    bool running = true;
    int choice = 0;

    // Boucle principale : elle tourne tant que "running" est true.
    while (running) {
        printMenu();
        choice = 0;

        // Si l'utilisateur entre quelque chose qui n'est pas un
        // nombre, std::cin echoue : il faut alors nettoyer la
        // saisie avant de proposer le menu de nouveau.
        if (!(std::cin >> choice)) {
            const bool endOfInput = std::cin.eof();
            std::cin.clear();

            if (endOfInput) {
                // La saisie est terminee (par exemple Ctrl+Z).
                running = false;
                break;
            }

            std::string restOfLine;
            std::getline(std::cin, restOfLine); // on jette la saisie invalide
            std::cout << std::endl;
            printInvalidOption();
            pressEnter();
            continue;
        }

        // L'utilisateur a appuye sur "Entree" apres le nombre :
        // on jette ce retour a la ligne, sinon le prochain
        // "Press Enter..." serait declenche par ce reliquat.
        {
            std::string restOfLine;
            std::getline(std::cin, restOfLine);
        }

        if (choice == 1) {
            CpuInfo cpu;
            getCpuInfo(cpu);
            printCpuInfo(cpu);
        } else if (choice == 2) {
            RamInfo ram;
            getRamInfo(ram);
            printRamInfo(ram);
        } else if (choice == 3) {
            SystemInfo systemInfo;
            getSystemInfo(systemInfo);
            printSystemInfo(systemInfo);
        } else if (choice == 4) {
            std::vector<DriveInfo> drives = getStorageInfo();
            printStorageInfo(drives);
        } else if (choice == 5) {
            std::vector<std::string> gpus = getGpuInfo();
            printGpuInfo(gpus);
        } else if (choice == 6) {
            CpuInfo cpu;
            RamInfo ram;
            SystemInfo systemInfo;
            std::vector<DriveInfo> drives = getStorageInfo();
            std::vector<std::string> gpus = getGpuInfo();
            getCpuInfo(cpu);
            getRamInfo(ram);
            getSystemInfo(systemInfo);
            printSystemReport(cpu, ram, systemInfo, drives, gpus);
        } else if (choice == 7) {
            if (ExportSystemReport()) {
                std::cout << std::endl;
                std::cout << "System report successfully created." << std::endl;
                std::cout << std::endl;
                std::cout << "File:" << std::endl;
                std::cout << "reports/system_report.txt" << std::endl;
                std::cout << std::endl;
            } else {
                std::cout << std::endl;
                std::cout << "Failed to create system report." << std::endl;
                std::cout << std::endl;
            }
        } else if (choice == 8) {
            running = false;
        } else {
            printInvalidOption();
        }

        // On attend "Entree" avant de proposer le menu de nouveau
        // (sauf quand on quitte le programme).
        if (running) {
            pressEnter();
        }
    }

    std::cout << "Goodbye!" << std::endl;
    return 0;
}
