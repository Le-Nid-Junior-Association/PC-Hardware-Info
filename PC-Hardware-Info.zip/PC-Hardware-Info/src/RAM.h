// RAM.h
// -------------------------------------------------------------------
// Declaration de la structure RamInfo et des fonctions qui
// lisent les informations de la memoire (getRamInfo) et qui
// les affichent a l'ecran (printRamInfo).
// -------------------------------------------------------------------

#ifndef RAM_H
#define RAM_H

// Petite structure qui stocke les informations de la memoire.
// Les valeurs sont stockees en gigaoctets (GB).
struct RamInfo {
    bool ok; // true si les informations ont etu lues correctement
    unsigned long long totalGb;
    unsigned long long usedGb;
    unsigned long long availableGb;
};

// Lit les informations de la memoire et remplit la structure.
void getRamInfo(RamInfo& ram);

// Affiche les informations de la memoire a l'ecran.
void printRamInfo(const RamInfo& ram);

#endif // RAM_H
