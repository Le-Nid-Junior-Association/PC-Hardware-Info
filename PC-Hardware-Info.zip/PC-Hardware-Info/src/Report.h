// Report.h
// -------------------------------------------------------------------
// Declaration de la fonction qui genere le rapport systeme dans le
// fichier texte "reports/system_report.txt".
// -------------------------------------------------------------------

#ifndef REPORT_H
#define REPORT_H

// Genere le fichier de rapport systeme.
// Retourne true si le fichier a ete cree correctement,
// false sinon.
bool ExportSystemReport();

#endif // REPORT_H
