// RAM.cpp
// -------------------------------------------------------------------
// Comment le programme lit les informations de la memoire :
//   - Windows : fonction GlobalMemoryStatusEx()
//   - Linux   : fichier /proc/meminfo (version de secours, voir README)
//
// La memoire utilisee est calculee ainsi :
//   utilisee = totale - disponible
// -------------------------------------------------------------------

#include "RAM.h"

#include <iostream>
#include <string>

#ifdef _WIN32
#include <windows.h>
#else
#include <fstream>
#include <sstream>
#endif

#ifdef _WIN32

void getRamInfo(RamInfo& ram) {
    // Valeurs par defaut, au cas ou l'appel echoue.
    ram.ok = false;
    ram.totalGb = 0;
    ram.usedGb = 0;
    ram.availableGb = 0;

    MEMORYSTATUSEX status;
    status.dwLength = sizeof(status);

    if (!GlobalMemoryStatusEx(&status)) {
        return; // erreur : les informations ne sont pas disponibles
    }

    const unsigned long long oneGb = 1024ULL * 1024ULL * 1024ULL;

    ram.totalGb = status.ullTotalPhys / oneGb;
    ram.availableGb = status.ullAvailPhys / oneGb;
    ram.usedGb = ram.totalGb - ram.availableGb;
    ram.ok = true;
}

#else // -------------------------------------------------------------
// Version de secours pour Linux (test du programme hors Windows).
// -------------------------------------------------------------

// Lit une valeur (en kilooctets) dans le fichier /proc/meminfo.
// Exemple : readMemInfoValueKb("MemTotal")
static long long readMemInfoValueKb(const std::string& key) {
    std::ifstream file("/proc/meminfo");
    if (!file.is_open()) {
        return -1;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Une ligne de /proc/meminfo a la forme :
        // "MemTotal:       16384 kB"
        if (line.rfind(key, 0) == 0) {
            std::istringstream numbers(line);
            std::string label;
            long long valueKb = 0;
            numbers >> label >> valueKb;
            return valueKb;
        }
    }
    return -1; // la cle n'a pas ete trouvee
}

void getRamInfo(RamInfo& ram) {
    ram.ok = false;
    ram.totalGb = 0;
    ram.usedGb = 0;
    ram.availableGb = 0;

    const long long totalKb = readMemInfoValueKb("MemTotal");
    const long long availableKb = readMemInfoValueKb("MemAvailable");

    if (totalKb > 0 && availableKb >= 0 && availableKb <= totalKb) {
        const unsigned long long oneGbInKb = 1024ULL * 1024ULL;
        ram.totalGb = static_cast<unsigned long long>(totalKb) / oneGbInKb;
        ram.availableGb = static_cast<unsigned long long>(availableKb) / oneGbInKb;
        ram.usedGb = ram.totalGb - ram.availableGb;
        ram.ok = true;
    }
}

#endif // _WIN32

// -------------------------------------------------------------------
// Affichage (identique sur tous les systemes)
// -------------------------------------------------------------------

void printRamInfo(const RamInfo& ram) {
    std::cout << "RAM" << std::endl;

    if (ram.ok) {
        std::cout << "Total: " << ram.totalGb << " GB" << std::endl;
        std::cout << "Used: " << ram.usedGb << " GB" << std::endl;
        std::cout << "Available: " << ram.availableGb << " GB" << std::endl;
    } else {
        std::cout << "Total: Unavailable" << std::endl;
        std::cout << "Used: Unavailable" << std::endl;
        std::cout << "Available: Unavailable" << std::endl;
    }

    std::cout << std::endl;
}
