// System.cpp
// -------------------------------------------------------------------
// Comment le programme lit les informations du systeme :
//   - architecture   : "constant"es definies par le compilateur
//                      (_M_X64 ou __x86_64__ si 64 bits, etc.)
//   - version Windows: registre Windows (ProductName)
//
// Sur les systemes non-Windows, la version de Windows est
// evidemment "Unavailable" (voir README).
// -------------------------------------------------------------------

#include "System.h"

#include <iostream>
#include <string>
#include <vector>

#ifdef _WIN32
#include <windows.h>
#endif

// -------------------------------------------------------------------
// Petites fonctions d'aide (en "static" : privees a ce fichier)
// -------------------------------------------------------------------

// Si le texte est vide, retourne "Unavailable", sinon le texte.
static std::string textOrUnavailable(const std::string& value) {
    if (value.empty()) {
        return "Unavailable";
    }
    return value;
}

// Convertit un nombre en texte. 0 (non disponible) devient
// "Unavailable".
static std::string numberOrUnavailable(int value) {
    if (value <= 0) {
        return "Unavailable";
    }
    return std::to_string(value);
}

// -------------------------------------------------------------------
// Fonctions principales
// -------------------------------------------------------------------

std::string getSystemArchitecture() {
    // Le compilateur definit des constantes speciales qui indiquent
    // l'architecture pour laquelle le programme est compile.
#if defined(_M_X64) || defined(__x86_64__)
    return "x64";
#elif defined(_M_IX86) || defined(__i386__)
    return "x86";
#elif defined(_M_ARM64) || defined(__aarch64__)
    return "arm64";
#else
    return "Unavailable";
#endif
}

#ifdef _WIN32

std::string readRegistryString(const char* path, const char* valueName) {
    HKEY hKey = nullptr;

    // On ouvre la cle du registre en mode "lecture".
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, path, 0, KEY_READ, &hKey) != ERROR_SUCCESS) {
        return "Unavailable";
    }

    char buffer[1024] = { 0 };
    DWORD bufferSize = sizeof(buffer) - 1; // on garde la place du '\0'
    DWORD valueType = 0;

    const LONG status = RegQueryValueExA(hKey, valueName, nullptr, &valueType,
                                         reinterpret_cast<BYTE*>(buffer), &bufferSize);

    RegCloseKey(hKey);

    // On ne garde la valeur que si elle est un texte (REG_SZ).
    if (status == ERROR_SUCCESS && valueType == REG_SZ && bufferSize > 0) {
        return std::string(buffer);
    }
    return "Unavailable";
}

#else // -------------------------------------------------------------
// Hors Windows : le registre n'existe pas.
// -------------------------------------------------------------

std::string readRegistryString(const char* path, const char* valueName) {
    (void)path;
    (void)valueName;
    return "Unavailable";
}

#endif

void getSystemInfo(SystemInfo& info) {
    info.architecture = getSystemArchitecture();

#ifdef _WIN32
    // Version de Windows, dans le registre.
    info.windowsVersion = readRegistryString(
        "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",
        "ProductName");
#else
    info.windowsVersion = "Unavailable";
#endif
}

void printSystemInfo(const SystemInfo& info) {
    std::cout << "SYSTEM" << std::endl;
    std::cout << "Architecture: " << textOrUnavailable(info.architecture) << std::endl;
    std::cout << "Windows: " << textOrUnavailable(info.windowsVersion) << std::endl;
    std::cout << std::endl;
}

void printSystemReport(const CpuInfo& cpu, const RamInfo& ram,
                       const SystemInfo& system,
                       const std::vector<DriveInfo>& drives,
                       const std::vector<std::string>& gpus) {
    std::cout << "================================" << std::endl;
    std::cout << "        SYSTEM REPORT" << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << std::endl;

    std::cout << "CPU" << std::endl;
    std::cout << "Name: " << textOrUnavailable(cpu.name) << std::endl;
    std::cout << "Cores: " << numberOrUnavailable(cpu.cores) << std::endl;
    std::cout << "Threads: " << numberOrUnavailable(cpu.threads) << std::endl;
    std::cout << std::endl;

    std::cout << "RAM" << std::endl;
    if (ram.ok) {
        std::cout << "Total: " << ram.totalGb << " GB" << std::endl;
        std::cout << "Used: " << ram.usedGb << " GB" << std::endl;
        std::cout << "Available: " << ram.availableGb << " GB" << std::endl;
    } else {
        std::cout << "Total: Unavailable" << std::endl;
        std::cout << "Used: Unavailable" << std::endl;
        std::cout << "Available: Unavailable" << std::endl;
    }
    std::cout << std::endl;

    std::cout << "STORAGE" << std::endl;
    if (drives.empty()) {
        std::cout << "Unavailable" << std::endl;
    } else {
        for (std::size_t i = 0; i < drives.size(); i = i + 1) {
            std::cout << drives[i].letter << std::endl;
            std::cout << "Total: " << drives[i].totalGb << " GB" << std::endl;
            std::cout << "Used: " << drives[i].usedGb << " GB" << std::endl;
            std::cout << "Free: " << drives[i].freeGb << " GB" << std::endl;
        }
    }
    std::cout << std::endl;

    std::cout << "GPU" << std::endl;
    if (gpus.empty()) {
        std::cout << "Unavailable" << std::endl;
    } else {
        for (std::size_t i = 0; i < gpus.size(); i = i + 1) {
            std::cout << "Name: " << gpus[i] << std::endl;
        }
    }
    std::cout << std::endl;

    std::cout << "SYSTEM" << std::endl;
    std::cout << "Architecture: " << textOrUnavailable(system.architecture) << std::endl;
    std::cout << "Windows: " << textOrUnavailable(system.windowsVersion) << std::endl;

    std::cout << "================================" << std::endl;
    std::cout << std::endl;
}
