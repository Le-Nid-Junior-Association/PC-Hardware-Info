// Storage.h
// -------------------------------------------------------------------
// Declaration de la structure DriveInfo et des fonctions qui
// lisent les informations des disques (getStorageInfo) et qui
// les affichent a l'ecran (printStorageInfo).
// -------------------------------------------------------------------

#ifndef STORAGE_H
#define STORAGE_H

#include <string>
#include <vector>

// Petite structure qui stocke les informations d'un disque.
// Les valeurs sont stockees en gigaoctets (GB).
struct DriveInfo {
    std::string letter; // Exemple : "C:"
    unsigned long long totalGb;
    unsigned long long usedGb;
    unsigned long long freeGb;
};

// Lit les informations de tous les disques disponibles.
// Si aucun disque ne peut etre lu, le vector reste vide.
std::vector<DriveInfo> getStorageInfo();

// Affiche les informations des disques a l'ecran.
void printStorageInfo(const std::vector<DriveInfo>& drives);

#endif // STORAGE_H
