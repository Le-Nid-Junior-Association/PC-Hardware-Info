// CPU.h
// -------------------------------------------------------------------
// Declaration de la structure CpuInfo et des fonctions qui
// lisent les informations du processeur (getCpuInfo) et qui
// les affichent a l'ecran (printCpuInfo).
// -------------------------------------------------------------------

#ifndef CPU_H
#define CPU_H

#include <string>

// Petite structure qui stocke les informations du processeur.
struct CpuInfo {
    std::string name;         // Exemple : "AMD Ryzen 5 5600"
    int cores;                // Nombre de coeurs physiques (0 = non disponible)
    int threads;              // Nombre de threads logiques (0 = non disponible)
    std::string architecture; // "x64" ou "x86"
};

// Lit les informations du processeur et remplit la structure.
// Si une valeur ne peut pas etre lue, "Unavailable" est stocke
// (le programme n'invente jamais de valeur).
void getCpuInfo(CpuInfo& cpu);

// Affiche les informations du processeur a l'ecran.
void printCpuInfo(const CpuInfo& cpu);

#endif // CPU_H
